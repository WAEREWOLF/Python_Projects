
def afisare(ops):
	for i in range(len(ops)):
		print("op({},{}) = {}\n".format(ops[i][0], ops[i][1], ops[i][2]))

#(a op b) = (b op a) , pentru orice a, b din A
def comutativitate(ops, A):
	for a in A:
		for b in A:
			for i in range(len(ops)):
				if ops[i][0] == a and ops[i][1] == b:
					res1 = ops[i][2]
				if ops[i][0] == b and ops[i][1] == a:
					res2 = ops[i][2]
			if res1 != res2:
				return False
	return True

#(a op b) op c = a op (b op c), pentru orice a, b, c din A
def asociativitate(ops, A):
	 for a in A:
	 	for b in A:
	 		for c in A:
	 			#se cauta z1 = (a op b) si z2 = (b op c)
	 			for i in range(len(ops)):
	 				if ops[i][0] == a and ops[i][1] == b:
	 					z1 = ops[i][2]
	 				if ops[i][0] == b and ops[i][1] == c:
	 					z2 = ops[i][2]
	 			#se cauta res1 = z1 op c si res2 = a op z2
	 			for i in range(len(ops)):
	 				if ops[i][0] == z1 and ops[i][1] == c:
	 					res1 = ops[i][2]
	 				if ops[i][0] == a and ops[i][1] == z2:
	 					res2 = ops[i][2]
	 			#se compara res1 cu res2
	 			if res1 != res2:
	 				return False
	 return True
def neutru(ops, A):
	#pentru fiecare element neutru posibil se verifica daca respecta conditia
	for e in A: 
		found = 1 #se presupune ca exista
		for a in A:
			for i in range(len(ops)):
				if ops[i][0] == a and ops[i][1] == e: #se caut valoarea (a op e)
					res1 = ops[i][2]	
				if ops[i][0] == e and ops[i][1] == a: #se cauta vloarea (e op a)
					res2 = ops[i][2]
			if res1 != e or res2 != e: # daca una dintre (a op e), (e op a) != e atunci se trece la urmatorul e 
				found = 0
				break
		if found == 1: #daca se respecta conditiile se returneaza elementul neutru
			return e
	return False

def grup(ops, A):	
	if asociativitate(ops, A) == False: #daca nu este asociativitate nu mai are rost sa cautam inversul 
		print("Operatia nu e grup")
		return
	if neutru(ops, A) == False: #daca nu este element neutru nu mai are rost sa cautam inversul 
		print("Operatia nu e grup")
		return 
	else:
		#se verifica proprietatea de invers
		E = neutru(ops, A)
		ok1 = False
		ok2 = False
		for a in A:
			for a_inverse in A:
				for i in range(len(ops)):
					if ops[i][0] == a and ops[i][1] == a_inverse and ops[i][2] == E:
						ok1 = True
					if ops[i][0] == a_inverse and ops[i][1] == a and ops[i][2] == E:
						ok2 = True
		if ok1 == True:  
			print("Operatia este grup ", end = "")
			if ok2 == True:
				print("comutativ")
			return
	print("Operatia nu este grup")
	
