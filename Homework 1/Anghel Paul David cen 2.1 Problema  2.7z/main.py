from operatii_binare import *


#citim nr de elemente ale multimii
n = int(input("Dati nr. de elemente ale multimii A: "))
#creeam multimea A finita si vida la inceput
A = []
#citim elementele multimii
print("Dati elementele multimii A ")

for i in range(n):
    print("Introduceti element:")
    A.append(int(input()))
print("A= ",A)
print("Dati valoarile lui z pentru fiecare pereche (a, b) din A x A: ")
#op = operatii si 's' mai multe
ops = []
#pentru fiecare pereche (x, y) din A x A se citeste valoarea z ce reprezinta valoarea operatiei aplicata perechii respective 
for x in A:
	for y in A:
		z = int(input("{} op {} = ".format(x, y)))
		#presupunem ca facem citirea corecta si fiecare z care il citim de la tastatura apartine lui A
		ops.append([x, y, z])
afisare(ops)
if comutativitate(ops, A) == True:
	print("Operatia este comutativa")
else:
	print("Operatia nu este comutativa")
if asociativitate(ops, A) == True:
	print("Operatia este asociativa")
else:
	print("Operatia nu este asociativa")
if neutru(ops, A) == False:
	print("Operatia nu are element neutru")
else:
	print("Elementul neutru este: {}".format(neutru(ops, A)))
grup(ops, A)