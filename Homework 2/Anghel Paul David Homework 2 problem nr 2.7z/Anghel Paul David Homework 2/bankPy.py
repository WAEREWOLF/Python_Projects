import sys
import os
import time

class BankAccount:
    bankName='BCR'
    #constructor   
    def __init__(self,name,password,balance=0.0):
        self.name=name
        self.balance=balance
        self.password=password
    #destructor 
    def __del__(self):
        print("Account was deleted!\n")
    
        #functia care preia doua obiecte de tip BankAccount si face tranzactia intre campurile balance de la obiectele respective
    def transactionbetweenacc(self,acc2,ammount):
        if self.balance>=ammount:
            acc2.balance=ammount
            self.balance=self.balance-ammount
            print("Transfer complete!\n")
        else: print("Insufficient funds!\n")
            

     #adauga o valoare in campul balance al unui obiect care apeleaza functia
    def deposit(self,amount):
        self.balance=self.balance+amount
        print('After Deposit your Balance is:',self.balance)
    
    #afiseaza numele bancii, numele propietarului, parola contului si cantitatea de bani memorata in campul balance
    def showstatus(self):
           print("\nBank name: ",self.bankName)
           print("Account name: ",self.name)
           print("Account password: ",self.password)
           print("Account balance: ",self.balance," lei\n")
       
    #functie care extrage 'bani' din cont doar daca cantitatea pe care o are in cont este mai mare decat cantitatea pe care doreste sa o extraga
    def withdraw(self,amount):
        if amount>self.balance:
            print('Sorry... Insufficient Funds!\n')
           
        else:
            self.balance=self.balance-amount
            print("After withdraw your Balance is:",self.balance)
    

    

#Sunt niste variabile care memoreaza daca a fost creat contul(ex: created1 pt contul 1, created2 pt contul 2 etc)
created1=False
created2=False
created3=False
#o variabila care memoreaza cate conturi se pot creea, o sa scada valoare odata cu creearea unui cont, si creste valoare daca am sters un cont actual (nr total de conturi posibile in acelasi timp al unui user este de 3)
nrAcc=3

while True:
    print("****** Welcome to ",BankAccount.bankName," ******\n")
    os.system("color 3e")
    print('C- Create account\nL-Log in\nE-Exit\n')
    option=input('Choose Your Option: ')
           
    if option=='C' or option=='c':
        os.system('cls')
        print('****** Create account ******')
        print("You can make 3 accounts, ",nrAcc," left!\n")
        #if the maximum accounts was reached then the user must delete one of the existing accounts if he want to create one more
        if nrAcc==0:
           
            print("You cant make new accounts, log in or delete one of your accounts!\n")
            time.sleep(2)
            os.system('cls')
                
        name=input('Username: ')
        password=input('Password: ')
        
       #De fiecare data cand este creat un nou cont, verificam daca nu este deja un cont creeat in obiectul respectiv(c1 - contul 1, c2-contul 2, c3- contul 3)
       #Acest lucru exceleaza si atunci cand sunt creeate toate 3 conturile, si stergem unul dintre ele, iar apoi creeam un altul si programul va stii sa creeze contul intr-un obiect gol, astfel evita incarcarea unui obiect care deja tine un cont
        if  created1==False:
          c1=BankAccount(name,password)
          created1=True
         
        elif created2==False:
            c2=BankAccount(name,password)
            created2=True
            
        elif created3==False:
            c3=BankAccount(name,password)
            created3=True
           
           
        else: 
              print("You cant make more then 3 accounts!\n")
              time.sleep(2)
              os.system('cls')
                      
        print("Your Account was Created, you can Log in now!\n")
        nrAcc=nrAcc-1
        time.sleep(2.5)
        os.system('cls')
    elif option=='L' or option=='l':
        os.system('cls')
        print('****** Log in ******\n')
        #intrebam daca a fost creeat cel putin un cont pentru a fii posibila logarea intr-un cont, altfel se cere creearea unui cont mai intai
        if created1==True or created2==True or created3==True:
         aname=input('Username: ')
         apassword=input('Password: ')
        #intrebam daca a fost creeat contul 1, ca apoi sa vedem daca se nimereste parola si username-ul de la contul 1, altfel parola incorecta
         if created1==True:
          if aname==c1.name and apassword==c1.password :
            print("Log in successful!\n")
            time.sleep(2)
            os.system('cls')
            #daca s-a introdus parola si userul corespunzator se deschide meniul unui user logat care ii permite sa: depoziteze o suma, extraga o suma, sa faca transfer cu alt cont, show status, sign out
            while True:
                os.system("color 4f")
                print("Hello",c1.name,"!\n")
                #afisarea meniului si optiunilor pe care le are un user logat
                print('1-Deposit\n2-WithDraw\n3-Show Status\n4-Transfer between accounts\n5-Delete Account\n6-Sign out\n')
                option2=int(input('Choose your Option: '))
                if option2==1:
                    #daca se selecteaza 1 atunci se cere valoare care sa fie introdusa in contul respectiv
                     amount=float(input('Enter Amount:'))
                     c1.deposit(amount)
                     time.sleep(2.5)
                     os.system('cls')
                elif option2==2:
                    #daca selecteaza 2 atunci se cere valoare pe care doreste userul sa o extraga din cont, este posibil acest lucru doar daca valoare pe care dosresc sa o extrag este mai Mare decat valorea pe care o am in cont
                    amount=float(input('Enter amount to withdraw:'))
                    c1.withdraw(amount)
                    time.sleep(2.5)
                    os.system('cls')
                elif option2==3:
                    #daca selecteaza 3 atunci este apelata functia showstatus care afiseaza informatiile despre cont
                     c1.showstatus()
                     time.sleep(2)
                     os.system('cls')          
                elif option2==4:
                  #doar daca am deja 2 conturi disponibile atunci putem face un transfer intre doua conturi, altfel se afiseaza mesajul corespunzator
                 if nrAcc<2:
                       
                       anAcc=input("Insert the username of the account you want to transfer: ")
                       anAmmount=int(input("Insert the ammount of lei you want to transfer: "))
                       if anAcc==c1.name:
                        print("You cant make a transaction with yourself!\n")
                        time.sleep(2.5)
                        os.system('cls')
                      #in functie cu ce parametrii apelam functia transactionbetweenacc programul isi da seama intre ce obiecte sa faca transferul
                      #(pentru a fii verificata functia (in consola) se fac minim 2 conturi, se face o tranzactie cu contul x in y iar apoi se da Sign out din contul x si se logheaza cu contul y, si se apasa showstatus pentu a vedea daca transferul a avut loc)
                       elif anAcc==c2.name:
                        c1.transactionbetweenacc(c2,anAmmount)
                        time.sleep(2)
                        os.system('cls')
                       elif anAcc==c3.name:
                        c1.transactionbetweenacc(c3,anAmmount)
                        time.sleep(2)
                        os.system('cls')
                     
                 else:
                     print("You must have at least 2 accounts to make this action!\n") 
                     time.sleep(2.5)
                     os.system('cls')
                                            
                elif option2==5:
                     #de fiecare data cand stergem contul variabila care tine nr de conturi (nrAcc) este incrementata (ca sa mai pot creea un alt cont), created 1 va deveni False si este apelat destructorul
                     nrAcc=nrAcc+1
                     del c1
                     created1=False
                     time.sleep(2)
                     os.system('cls')
                     break
                elif option2==6:
                     #se iese din meniul unui user logat si se revine la meniul principal unde se poate creea un cont, logare, sau exit
                     print("\nBye",c1.name)
                     time.sleep(2)
                     os.system('cls')
                     break
                else: 
                    print('Invalid option!\n')
                    time.sleep(2)
                    os.system('cls')
        #daca este deja creeat contul 2 atunci verifica daca se nimeresc parola si user-ul altfel nu se face logarea in cont
        #(acelasi lucru ca mai sus se efectueaza pentru cele 3 obiecte care reprezinta cele 3 conturi pe care un user le poate creea)
          elif created2==True:
            if aname==c2.name and apassword==c2.password :
             print("Log in successful!\n")
             time.sleep(2)
             os.system('cls')
             while True:
                 os.system("color 5f")
                 print("Hello",c2.name,"!\n")
                 print('1-Deposit\n2-WithDraw\n3-Show Status\n4-Transfer between accounts\n5-Delete Account\n6-Sign out\n')
                 option3=int(input('Choose your Option: '))
                 if option3==1:
                     amount=float(input('Enter Amount:'))
                     c2.deposit(amount)
                     time.sleep(2)
                     os.system('cls')
                 elif option3==2:
                    amount=float(input('Enter amount to withdraw:'))
                    c2.withdraw(amount)
                    time.sleep(2)
                    os.system('cls')
                 elif option3==3:
                     c2.showstatus()
                     time.sleep(3)
                     os.system('cls')
                 elif option3==4:
                    if(nrAcc<2):
                     anAcc2=input("Insert the username of the account you want to transfer: ")
                     anAmmount2=int(input("Insert the ammount of lei you want to transfer: "))
                     if anAcc2==c2.name:
                        print("You cant make a transaction with yourself!")
                        time.sleep(2)
                        os.system('cls')
                     elif anAcc2==c1.name:
                          c2.transactionbetweenacc(c1,anAmmount2)
                          time.sleep(2)
                          os.system('cls')
                         
                     elif anAcc2==c3.name:
                         c2.transactionbetweenacc(c3,anAmmount2)
                         time.sleep(2)
                         os.system('cls')
                         
                    else: 
                              print("You must have at least 2 accounts to make this action!\n")
                              time.sleep(2)
                              os.system('cls')
                 elif option3==5:
                     nrAcc=nrAcc+1
                     del c2
                     time.sleep(2)
                     os.system('cls')
                     created2=False
                     
                     break
                 elif option3==6:
                     print("\nBye",c2.name)
                     time.sleep(2)
                     os.system('cls')
                     break
                 else: 
                     print('Invalid option!\n')
                     time.sleep(2)
                     os.system('cls')

            elif created3==True:
             if aname==c3.name and apassword==c3.password:
              print("Log in successful!\n")
              time.sleep(2)
              os.system('cls')
              while True:
                 os.system("color 6f")
                 print("Hello",c3.name,"!\n")
                 print('1-Deposit\n2-WithDraw\n3-Show Status\n4-Transfer between accounts\n5-Delete Account\n6-Sign out\n')
                 option4=int(input('Choose your Option: '))
                 if option4==1:
                     amount=float(input('Enter Amount:'))
                     c3.deposit(amount)
                     time.sleep(2)
                     os.system('cls')
                 elif option4==2:
                    amount=float(input('Enter amount to withdraw:'))
                    c3.withdraw(amount)
                    time.sleep(2)
                    os.system('cls')
                 elif option4==3:
                     c3.showstatus
                     time.sleep(3)
                     os.system('cls')
                 elif option4==4:
                    if nrAcc<2:
                     anAcc3=input("Insert the username of the account you want to transfer: ")
                     anAmmount3=int(input("Insert the ammount of lei you want to transfer: "))
                    if anAcc3==c3.name:
                        print("You cant make a transaction with yourself!\n")
                        time.sleep(2)
                        os.system('cls')
                    elif anAcc3==c2.name:
                        c3.transactionbetweenacc(c2,anAmmount3)
                        time.sleep(2)
                        os.system('cls')
                    elif anAcc3==c1.name:
                        c3.transactionbetweenacc(c1,anAmmount3)
                        time.sleep(2)
                        os.system('cls')
                    else: 
                        print("You must have at least 2 accounts to make this action!\n")
                        time.sleep(2)
                        os.system('cls')
                 elif option4==5:
                     nrAcc=nrAcc+1
                     del c3
                     created3=False
                     time.sleep(2)
                     os.system('cls')
                     break
                 elif option4==6:
                     print("\nBye",c3.name)
                     time.sleep(2)
                     os.system('cls')
                     break
                 else: 
                     print('Invalid option!\n')
                     time.sleep(2)
                     os.system('cls')
          else: 
                print('Username or Password incorrect!\n')
                time.sleep(2)
                os.system('cls')
          
        else: 
                print("Create an account first and then Log in!\n")
                time.sleep(2.5)
                os.system('cls')
                        
    
    elif option=='E' or option=='e':
        print('Thanks for Visiting!\n')
        sys.exit()
    else:
        print('Invalid option!\n')
        time.sleep(2)
        os.system('cls')

